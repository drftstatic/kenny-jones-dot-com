---
name: vhs-aesthetic
description: >
  Use this skill when implementing CRT monitor frames, VHS scanline overlays,
  VHS tracking line animations, text glitch effects, camcorder timestamp UI,
  REC indicator overlays, VHS static noise patterns, or any retro analog
  video aesthetic. Do NOT use for general CSS animations or non-VHS styling.
---

# VHS / CRT Aesthetic Implementation Guide

## Core Principles

1. **Effects are overlays, not content.** Every VHS/CRT effect must use `pointer-events: none` and `position: fixed` so it never blocks interaction with actual content.

2. **Subtlety over spectacle.** VHS effects should be felt, not stared at. If a user consciously notices the scanlines, they're too strong. Target opacity ranges:
   - Scanlines: 2-4% opacity
   - Tracking line: 5-8% opacity
   - CRT vignette: 30-50% at edges
   - Static noise: 4-5% opacity

3. **Performance is non-negotiable.** All animations must use `transform` and `opacity` only (GPU-composited properties). Never animate `background-position` on large elements — use `transform: translateX/Y` instead. Add `will-change: transform` to animated elements.

4. **Respect `prefers-reduced-motion`.** Wrap all VHS animations in a media query check. When reduced motion is preferred, disable all animations and show a clean, static version with just the color palette and typography.

```css
@media (prefers-reduced-motion: reduce) {
  .scanlines,
  .vhs-tracking-line,
  .vhs-static,
  .glitch-text {
    animation: none !important;
  }
  .scanlines { display: none; }
  .vhs-tracking-line { display: none; }
}
```

5. **Layer ordering matters.** Use the z-index stack defined in DESIGN.md. Content must always be readable beneath overlays.

## Implementation Patterns

### Pattern: CRT Frame
- Use a `position: fixed; inset: 0` container with `pointer-events: none`
- Apply `box-shadow: inset` for vignette darkening at edges
- Add corner bracket pseudo-elements for viewfinder feel
- On mobile (< 768px), remove the full border and show only corner brackets

### Pattern: Scanlines
- Use `repeating-linear-gradient` on a fixed overlay
- Line height: 2px transparent + 2px at ~3% opacity
- This creates ~125 horizontal lines per 500px of viewport — enough to feel analog without being distracting

### Pattern: VHS Tracking Line
- A single horizontal band (3px tall) that translates vertically across the screen
- Use `linear-gradient` with transparent edges so it fades in/out
- Animation duration: 6-10 seconds (slow, ambient movement)
- `animation-timing-function: linear` (constant speed, like real tracking drift)

### Pattern: Text Glitch
- Use `clip-path: inset()` to show random horizontal slices of text
- Combine with small `transform: translate()` offsets for displacement
- Run once on load (0.3-0.5s duration), then hold final frame (`forwards` fill)
- Only apply to hero headlines — never to body text or navigation

### Pattern: VHS Static / Noise
- CSS-only using `repeating-radial-gradient` with tiny sizes (2-4px)
- Animate `background-position` with `steps()` for a flickering effect
- Keep step count low (4-6 steps) for that authentic choppy look
- Use only on specific elements (corrupted card, 404 page), never full-page

### Pattern: Camcorder Timestamp
- Fixed position, bottom-left
- Format: `MMM DD YYYY  H:MM:SS AM/PM` (e.g., `FEB 14 2026  2:34:17 PM`)
- Update via `setInterval` every 1000ms
- Use `requestAnimationFrame` cleanup on unmount
- Font: IBM Plex Mono, 11px, phosphor green at 60% opacity

### Pattern: REC Indicator
- Fixed position, top-right
- Red dot (`#ff3333`) with CSS blink animation (2s cycle)
- Text "REC" next to the dot
- The dot should feel like a real recording indicator — smooth fade, not abrupt on/off

### Pattern: News Ticker
- Fixed position, bottom of viewport
- Use a flex container with duplicated content for seamless loop
- `animation: ticker-scroll [duration] linear infinite`
- Duration scales with content length — calculate based on total text width
- Background: near-black with 90% opacity, green top border

## Common Mistakes to Avoid

1. **Don't animate `filter` properties** on overlay elements — `filter: blur()` and `filter: brightness()` are expensive and cause repaint.
2. **Don't use video elements** for VHS effects — CSS is sufficient and much more performant.
3. **Don't apply glitch effects to interactive elements** — buttons, links, and form fields must always be stable and readable.
4. **Don't forget cleanup** — any `setInterval` (timestamp), `addEventListener` (Konami code), or `AudioContext` must be cleaned up in React `useEffect` return functions.
5. **Don't make the CRT frame too thick** — 2-3px border max. This isn't a literal TV frame, it's a suggestion of one.
6. **Don't use `mix-blend-mode`** on overlay layers — it causes unexpected interactions with underlying content colors.
